WEBPHONE COMPANION

Esta es una aplicación web instalable (PWA), no una app nativa de App Store.

Para probar:
1. Descomprime el ZIP y publica la carpeta en un hosting HTTPS estático (por ejemplo, GitHub Pages).
2. Abre la dirección HTTPS en Safari en el iPhone.
3. Pulsa Compartir > Añadir a pantalla de inicio.
4. Abre WebPhone desde el icono nuevo.

IMPORTANTE:
- No es posible instalar una PWA completa directamente desde un archivo ZIP en iPhone.
- El navegador integrado usa un iframe. Muchos sitios bloquean ser mostrados dentro de otras páginas por seguridad.
- Si una página lo bloquea, pulsa "Abrir en Safari / navegador".
- No puede funcionar como una capa superpuesta sobre Minecraft ni comunicarse automáticamente con el juego.
